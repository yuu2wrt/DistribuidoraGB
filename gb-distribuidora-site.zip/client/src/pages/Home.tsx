import { useEffect, useState } from "react";
import {
  ArrowUpRight,
  ChevronDown,
  Clock3,
  MapPin,
  Menu,
  Navigation,
  PackageCheck,
  Wine,
  X,
} from "lucide-react";

const MAP_URL = "https://maps.app.goo.gl/EQFgrKzvWEdbi3N1A";
const WHATSAPP_URL = "https://wa.me/5527997748932";
const OFFICIAL_LOGO_URL = ""; // Inserir aqui a URL do arquivo original da logo oficial quando disponibilizado.
const ADDRESS_LINES = ["Rua Republica, 170", "Vila Batista, Vila Velha — ES", "29116-150"];
const HOURS = [
  ["Domingo", "10:00–00:00"],
  ["Segunda-feira", "10:00–00:00"],
  ["Terça-feira", "10:00–00:00"],
  ["Quarta-feira", "10:00–00:00"],
  ["Quinta-feira", "10:00–00:00"],
  ["Sexta-feira", "10:00–02:00"],
  ["Sábado", "10:00–02:00"],
];

const categories = [
  { number: "01", title: "Bebidas", description: "Cervejas, refrigerantes, água, sucos e opções para o seu rolê." },
  { number: "02", title: "Copão", description: "Escolha sua base, combine e consulte a disponibilidade." },
  { number: "03", title: "Destilados", description: "Gin, whisky, vodka, cachaça, rum, conhaque e licor." },
  { number: "04", title: "Tabacaria", description: "Cigarros, tabaco, seda, piteira, filtros e acessórios." },
  { number: "05", title: "Cuia e Tereré", description: "Cuia, bomba, erva, copos e acessórios." },
  { number: "06", title: "Conveniência", description: "Salgadinhos, doces, balas, amendoim e gelo." },
];

const copaoOptions = [
  "Gin",
  "Whisky",
  "Vodka",
  "Cachaça",
  "Gin com energético",
  "Whisky com energético",
  "Vodka com energético",
  "Opções com frutas",
];

const drinkGroups = ["Cervejas", "Refrigerantes", "Água", "Sucos", "Energéticos", "Red Bull", "Start", "Gelo"];
const spiritGroups = ["Gin", "Whisky", "Vodka", "Cachaça", "Rum", "Conhaque", "Licor"];

function Wordmark({ compact = false }: { compact?: boolean }) {
  if (OFFICIAL_LOGO_URL) {
    return <img className="official-logo" src={OFFICIAL_LOGO_URL} alt="GB Distribuidora" />;
  }

  return (
    <span className="wordmark" aria-label="GB Distribuidora">
      <span className="wordmark-fallback">GB DISTRIBUIDORA</span>
      {!compact && <span className="wordmark-note">IDENTIDADE OFICIAL A INSERIR</span>}
    </span>
  );
}

function DirectionButton({ className = "", children = "Como chegar" }: { className?: string; children?: React.ReactNode }) {
  return (
    <a className={`button button-outline ${className}`} href={MAP_URL} target="_blank" rel="noreferrer">
      {children}
      <Navigation size={16} strokeWidth={2.2} />
    </a>
  );
}

function ContactButton({ className = "" }: { className?: string }) {
  if (WHATSAPP_URL) {
    return (
      <a className={`button button-primary ${className}`} href={WHATSAPP_URL} target="_blank" rel="noreferrer">
        Pedir pelo WhatsApp
        <ArrowUpRight size={16} strokeWidth={2.3} />
      </a>
    );
  }
  return (
    <span className={`button button-muted ${className}`} title="Aguardando o número oficial de WhatsApp">
      WhatsApp em atualização
    </span>
  );
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="site-shell">
      <header className={`site-header ${scrolled ? "is-scrolled" : ""}`}>
        <div className="header-inner">
          <a href="#inicio" className="brand-link" onClick={closeMenu}><Wordmark /></a>
          <nav className="desktop-nav" aria-label="Navegação principal">
            <a href="#inicio">Início</a>
            <a href="#bebidas">Bebidas</a>
            <a href="#copao">Copão</a>
            <a href="#tabacaria">Tabacaria</a>
            <a href="#localizacao">Localização</a>
          </nav>
          <div className="header-actions">
            <ContactButton className="header-contact" />
            <button className="menu-toggle" onClick={() => setMenuOpen((value) => !value)} aria-label={menuOpen ? "Fechar menu" : "Abrir menu"} aria-expanded={menuOpen}>
              {menuOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>
        {menuOpen && (
          <nav className="mobile-nav" aria-label="Navegação para celular">
            {[["Início", "#inicio"], ["Bebidas", "#bebidas"], ["Copão", "#copao"], ["Tabacaria", "#tabacaria"], ["Localização", "#localizacao"]].map(([label, href]) => (
              <a key={href} href={href} onClick={closeMenu}>{label}</a>
            ))}
            <DirectionButton className="mobile-direction" />
          </nav>
        )}
      </header>

      <main>
        <section className="hero" id="inicio">
          <div className="hero-image" role="img" aria-label="Foto pública do interior da Distribuidora do Gb" />
          <div className="hero-noise" />
          <div className="hero-content page-width">
            <div className="hero-eyebrow"><span className="live-dot" /> Vila Batista · Vila Velha, ES</div>
            <p className="hero-kicker">Bebidas geladas para a resenha</p>
            <h1><span>GB</span> DISTRIBUIDORA</h1>
            <div className="hero-bottom">
              <p className="hero-copy">Bebidas, copão, tabacaria e conveniência. Tudo para o seu rolê em um só lugar.</p>
              <div className="hero-buttons">
                <DirectionButton className="hero-direction">Como chegar</DirectionButton>
                <a href="#categorias" className="text-link">Ver opções <ChevronDown size={16} /></a>
              </div>
            </div>
          </div>
          <div className="hero-index" aria-hidden="true"><span>01</span><i /> 06</div>
        </section>

        <section className="quick-bar" aria-label="Informações públicas do estabelecimento">
          <div className="page-width quick-bar-inner">
            <div className="quick-item"><MapPin size={18} /><span>{ADDRESS_LINES[0]}<br /><strong>Vila Batista, Vila Velha/ES</strong></span></div>
            <div className="quick-item"><Clock3 size={18} /><span>Horário de funcionamento<br /><strong>Dom–Qui 10:00–00:00 · Sex–Sáb até 02:00</strong></span></div>
            <a className="quick-link" href={MAP_URL} target="_blank" rel="noreferrer">Abrir no Maps <ArrowUpRight size={16} /></a>
          </div>
        </section>

        <section className="section categories-section" id="categorias">
          <div className="page-width">
            <div className="section-heading split-heading">
              <div><p className="section-tag">O que tem na GB</p><h2>ENCONTRE O QUE<br />VOCÊ PROCURA.</h2></div>
              <p className="section-intro">Seleção direta para completar a sua noite. Consulte a disponibilidade na loja.</p>
            </div>
            <div className="category-grid">
              {categories.map((category, index) => (
                <article key={category.number} className={`category-card category-${index + 1}`}>
                  <div className="category-number">{category.number}</div>
                  <div className="category-card-content"><h3>{category.title}</h3><p>{category.description}</p></div>
                  <span className="card-arrow"><ArrowUpRight size={19} /></span>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="section copao-section" id="copao">
          <div className="page-width copao-layout">
            <div className="copao-info">
              <p className="section-tag">Feito para o seu gosto</p>
              <h2>COPÃO<br /><em>NA MEDIDA.</em></h2>
              <p className="large-copy">Escolha sua bebida e monte seu copão. Das combinações clássicas às opções com energético e frutas.</p>
              <div className="copao-note"><Wine size={18} /><span>Preços e disponibilidade devem ser confirmados diretamente com a loja.</span></div>
              <ContactButton />
            </div>
            <div className="copao-list-wrap">
              <p className="list-label">OPÇÕES PARA CONSULTA</p>
              <ol className="copao-list">
                {copaoOptions.map((option, index) => <li key={option}><span>0{index + 1}</span>{option}<i /></li>)}
              </ol>
              <p className="availability">CONSULTE DISPONIBILIDADE</p>
            </div>
          </div>
        </section>

        <section className="section drinks-section" id="bebidas">
          <div className="page-width drinks-layout">
            <div className="shop-photo photo-left" role="img" aria-label="Foto pública de produtos no interior da Distribuidora do Gb"><div className="photo-label">Foto pública<br />do estabelecimento</div></div>
            <div className="drinks-copy">
              <p className="section-tag">Gelada para o rolê</p>
              <h2>BEBIDAS<br />GELADAS.</h2>
              <p>Variedade essencial, sem complicação. Para levar, dividir ou deixar a resenha completa.</p>
              <div className="chip-list">{drinkGroups.map((item) => <span key={item}>{item}</span>)}</div>
              <DirectionButton />
            </div>
          </div>
        </section>

        <section className="section spirits-section">
          <div className="page-width spirits-layout">
            <div className="spirits-copy"><p className="section-tag">Base para o copão</p><h2>DESTILADOS.</h2><p>Opções para montar do seu jeito. Consulte a disponibilidade no local.</p></div>
            <div className="spirits-cloud">{spiritGroups.map((item, index) => <span className={`spirit spirit-${index + 1}`} key={item}>{item}</span>)}</div>
          </div>
        </section>

        <section className="section tabacaria-section" id="tabacaria">
          <div className="tabacaria-image" role="img" aria-label="Foto pública do estabelecimento" />
          <div className="tabacaria-overlay" />
          <div className="page-width tabacaria-content">
            <p className="section-tag">Prático e direto</p>
            <h2>TABACARIA<br />& ACESSÓRIOS.</h2>
            <p>Itens para a sua conveniência: cigarros, tabaco, seda, piteiras, filtros, isqueiros, tesouras e dichavadores.</p>
            <div className="tabacaria-tags"><span>Cigarros</span><span>Tabaco</span><span>Seda</span><span>Piteiras</span><span>Filtros</span><span>Isqueiros</span></div>
          </div>
        </section>

        <section className="section convenience-section">
          <div className="page-width convenience-grid">
            <div><p className="section-tag">Para completar</p><h2>CUIA, TERERÉ<br />E CONVENIÊNCIA.</h2></div>
            <div className="convenience-list"><span>Cuia</span><span>Bomba</span><span>Erva</span><span>Copos</span><span>Salgadinhos</span><span>Doces</span><span>Balas</span><span>Gelo</span></div>
            <div className="convenience-stamp"><PackageCheck size={24} /><p>Tudo em um só ponto.<br /><strong>Consulte na loja.</strong></p></div>
          </div>
        </section>

        <section className="contact-strip">
          <div className="page-width contact-strip-inner">
            <div><p className="section-tag section-tag-dark">VAI TER ROLÊ?</p><h2>CONFIRA AS OPÇÕES<br />NA <em>GB.</em></h2></div>
            <div className="contact-strip-actions"><p>O telefone e o WhatsApp não estão publicados na ficha do estabelecimento. Enquanto isso, use o mapa para chegar até a loja.</p><DirectionButton className="dark-direction" /></div>
          </div>
        </section>

        <section className="section location-section" id="localizacao">
          <div className="page-width location-grid">
            <div className="location-copy"><p className="section-tag">Visite a GB</p><h2>ONDE<br />ESTAMOS.</h2><p className="location-name">GB Distribuidora</p><address>{ADDRESS_LINES.map((line) => <span key={line}>{line}<br /></span>)}</address><p className="hours"><Clock3 size={16} /> Aberto agora · hoje até 00:00</p><div className="hours-table">{HOURS.map(([day, hours]) => <div key={day}><span>{day}</span><strong>{hours}</strong></div>)}</div><DirectionButton /></div>
            <a className="map-card" href={MAP_URL} target="_blank" rel="noreferrer" aria-label="Abrir a localização da Distribuidora do Gb no Google Maps"><div className="map-grid" /><div className="map-road road-one" /><div className="map-road road-two" /><div className="map-road road-three" /><div className="map-pin"><MapPin size={26} fill="currentColor" /><span>GB</span></div><div className="map-caption"><span>Vila Batista · Vila Velha/ES</span><strong>Abrir rota <ArrowUpRight size={16} /></strong></div></a>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="page-width footer-top"><div><Wordmark /><p>Bebidas, Copão, Tabacaria e Conveniência.</p></div><div className="footer-location"><p>ENDEREÇO</p><span>Rua Republica, 170 · Vila Batista<br />Vila Velha — ES · 29116-150</span></div><div className="footer-location"><p>HORÁRIO E CONTATO</p><span>Dom–Qui: 10:00–00:00<br />Sex–Sáb: 10:00–02:00<br /><a href={WHATSAPP_URL}>+55 27 99774-8932</a></span></div><a href={MAP_URL} target="_blank" rel="noreferrer" className="footer-route">Ver no Maps <ArrowUpRight size={16} /></a></div>
        <div className="page-width footer-bottom"><span>© 2026 GB Distribuidora. Todos os direitos reservados.</span><span>Dados de localização consultados no Google Maps.</span></div>
      </footer>

      {WHATSAPP_URL ? <a className="whatsapp-float" href={WHATSAPP_URL} target="_blank" rel="noreferrer">WhatsApp <ArrowUpRight size={17} /></a> : null}
    </div>
  );
}
